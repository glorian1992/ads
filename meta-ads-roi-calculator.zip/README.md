# Meta Ads ROI Calculator

A responsive ROI calculator for Meta Ads campaigns using HTML, CSS and JavaScript.